const mongoose = require('mongoose');

// Definir el esquema del usuario
const usuarioSchema = new mongoose.Schema({
  usuario: { type: String, required: true, unique: true }, // Nombre de usuario único
  email: { type: String, required: true, unique: true }, // Correo electrónico único
  password: { type: String, required: true }, // Contraseña hash
  fechaCreacion: { type: Date, default: Date.now }, // Fecha de creación del usuario
});

// Crear el modelo Usuario a partir del esquema
const Usuario = mongoose.model('Usuario', usuarioSchema);

// Conectar a MongoDB Atlas
mongoose.connect('mongodb+srv://<username>:<password>@cluster0.rr1bvjl.mongodb.net/<databaseName>?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Conexión exitosa a MongoDB Atlas');
})
.catch((error) => {
  console.error('Error al conectar a MongoDB Atlas:', error);
});

// Ejemplo de cómo utilizar el modelo Usuario
const nuevoUsuario = new Usuario({
  usuario: 'ejemplo',
  email: 'ejemplo@example.com',
  password: 'contraseña'
});

nuevoUsuario.save()
  .then(() => {
    console.log('Usuario guardado exitosamente:', nuevoUsuario);
  })
  .catch((error) => {
    console.error('Error al guardar el usuario:', error);
  });
