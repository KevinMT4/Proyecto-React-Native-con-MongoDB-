const mongoose = require('mongoose');

// Definir el esquema del producto gamer
const productoGamerSchema = new mongoose.Schema({
  nombre: { type: String, required: true }, // Nombre del producto
  categoria: { type: String, required: true }, // Ejemplo: "hardware", "juegos", "accesorios"
  marca: { type: String, required: true }, // Marca del producto
  precio: { type: Number, required: true }, // Precio del producto
  descripcion: String, // Descripción detallada del producto
});

// Crear el modelo ProductoGamer a partir del esquema
const ProductoGamer = mongoose.model('ProductoGamer', productoGamerSchema);

// Conectar a MongoDB Atlas
mongoose.connect('mongodb+srv://<username>:<password>@cluster0.rr1bvjl.mongodb.net/<databaseName>?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Conexión exitosa a MongoDB Atlas');
})
.catch((error) => {
  console.error('Error al conectar a MongoDB Atlas:', error);
});

// Ejemplo de cómo utilizar el modelo ProductoGamer
const nuevoProducto = new ProductoGamer({
  nombre: 'Ejemplo Producto',
  categoria: 'hardware',
  marca: 'Ejemplo Marca',
  precio: 100,
  descripcion: 'Descripción de ejemplo del producto'
});

nuevoProducto.save()
  .then(() => {
    console.log('Producto guardado exitosamente:', nuevoProducto);
  })
  .catch((error) => {
    console.error('Error al guardar el producto:', error);
  });
