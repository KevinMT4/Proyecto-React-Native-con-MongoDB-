const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const saltRounds = 10; // Número de rondas de sal para el hashing

const app = express();
const PORT = 3000;

mongoose.connect('mongodb+srv://kevinmurillo:12345@cluster0.rr1bvjl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const Schema = mongoose.Schema;

// Esquema para el modelo de Productos
const productoGamerSchema = new Schema({
  nombre: { type: String, required: true }, // Nombre del producto
  categoria: { type: String, required: true }, // Ejemplo: "hardware", "juegos", "accesorios"
  marca: { type: String, required: true }, // Marca del producto
  precio: { type: Number, required: true }, // Precio del producto
  descripcion: String, // Descripción detallada del producto
});

// Creación del modelo a partir del esquema definido
const ProductoGamer = mongoose.model('ProductoGamer', productoGamerSchema);

// Esquema para el modelo de Usuarios
const usuarioSchema = new Schema({
  usuario: { type: String, required: true, unique: true }, // Nombre de usuario único
  email: { type: String, required: true, unique: true }, // Correo electrónico único
  password: { type: String, required: true }, // Contraseña hash
  fechaCreacion: { type: Date, default: Date.now }, // Fecha de creación del usuario
});

// Antes de guardar el usuario, se realiza el hashing de la contraseña
usuarioSchema.pre('save', async function(next) {
  // Solo hash la contraseña si ha sido modificada (o es nueva)
  if (!this.isModified('contraseña')) return next();

  try {
    const salt = await bcrypt.genSalt(saltRounds);
    this.contraseña = await bcrypt.hash(this.contraseña, salt);
    return next();
  } catch (error) {
    return next(error);
  }
});

const Usuario = mongoose.model('Usuario', usuarioSchema);

app.post('/signup', async (req, res) => {
  // Tu código para registro de usuarios
});

app.post('/login', async (req, res) => {
  // Tu código para inicio de sesión
});

app.post('/productos', async (req, res) => {
  // Tu código para registrar productos
});

app.get('/productos', async (req, res) => {
  // Tu código para obtener productos
});

app.get('/datos', async (req, res) => {
  // Tu código para obtener datos
});

app.listen(PORT, () => {
  console.log(`Servidor en ejecución en http://localhost:${PORT}`);
});
